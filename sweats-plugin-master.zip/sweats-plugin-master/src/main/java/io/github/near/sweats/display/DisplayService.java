package io.github.near.sweats.display;

import io.github.near.sweats.SweatsPlugin;
import io.github.near.sweats.nick.NickService;
import io.github.near.sweats.perks.PerkService;
import io.github.near.sweats.rank.Rank;
import io.github.near.sweats.rank.RankService;
import io.github.near.sweats.stats.StatsService;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerStatisticIncrementEvent;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.scheduler.BukkitTask;

public final class DisplayService implements Listener {

    private static final long REFRESH_TICKS = 20L;

    private final SweatsPlugin plugin;
    private final StatsService stats;
    private final RankService ranks;
    private final NickService nicks;
    private final PerkService perks;
    private final Predicate<UUID> visible;
    private final Map<UUID, PlayerDisplay> displays = new HashMap<>();

    private DisplaySettings settings;
    private BukkitTask refreshTask;

    public DisplayService(
            final SweatsPlugin plugin,
            final StatsService stats,
            final RankService ranks,
            final NickService nicks,
            final PerkService perks,
            final Predicate<UUID> visible) {
        this.plugin = plugin;
        this.stats = stats;
        this.ranks = ranks;
        this.nicks = nicks;
        this.perks = perks;
        this.visible = visible;
        this.settings = DisplaySettings.from(plugin.getConfig());
        startRefreshTask();
        showAllOnline();
    }

    public void reloadSettings() {
        clearState();
        this.settings = DisplaySettings.from(plugin.getConfig());
        startRefreshTask();
        showAllOnline();
    }

    public void clearState() {
        stopRefreshTask();
        for (final Player player : Bukkit.getOnlinePlayers()) {
            final PlayerDisplay display = displays.get(player.getUniqueId());
            if (display != null) {
                display.clear(player);
            }
        }
        displays.clear();
    }

    /** Re-renders every online player after the rank list or its ordering changed. */
    public void refresh() {
        refreshAll();
    }

    /** Re-renders every online player after a nickname changed. */
    public void nickChanged(final UUID id) {
        refreshAll();
    }

    /** Updates one player's identity and every viewer's nametag entry for that player. */
    public void rankChanged(final UUID id) {
        final Player player = Bukkit.getPlayer(id);
        if (player == null || !visible.test(id)) {
            return;
        }

        final Rank rank = ranks.rankOf(id);
        // Update the player's entry on the main scoreboard team
        final Scoreboard mainBoard = Bukkit.getScoreboardManager().getMainScoreboard();
        final Team team = mainBoard.getTeam("ranks" + rank.key());
        if (team != null) {
            if (!team.hasEntry(player.getName())) {
                team.addEntry(player.getName());
            }
        }
        final PlayerDisplay own = displays.get(id);
        if (own != null) {
            own.updateRank(player, visibleOnline(player, Bukkit.getOnlinePlayers()));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(final PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        show(player);

        if (displays.containsKey(player.getUniqueId())) {
            final Rank rank = ranks.rankOf(player.getUniqueId());
            // Add to main scoreboard team
            final Scoreboard mainBoard = Bukkit.getScoreboardManager().getMainScoreboard();
            final Team team = mainBoard.getTeam("ranks" + rank.key());
            if (team != null) {
                team.addEntry(player.getName());
            }
        }
        refreshAll();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(final PlayerQuitEvent event) {
        final String playerName = event.getPlayer().getName();
        for (final PlayerDisplay display : displays.values()) {
            display.removeEntry(playerName);
        }
        displays.remove(event.getPlayer().getUniqueId());

        final List<? extends Player> remaining = Bukkit.getOnlinePlayers().stream()
                .filter(player -> !player.getUniqueId().equals(event.getPlayer().getUniqueId()))
                .toList();
        refreshAll(remaining);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onStatisticIncrement(final PlayerStatisticIncrementEvent event) {
        final Statistic statistic = event.getStatistic();
        if (statistic != Statistic.PLAYER_KILLS && statistic != Statistic.DEATHS) {
            return;
        }

        final PlayerDisplay display = displays.get(event.getPlayer().getUniqueId());
        if (display != null) {
            display.updateSidebar(
                    event.getPlayer(),
                    visibleOnline(event.getPlayer(), Bukkit.getOnlinePlayers()));
        }
    }

    private void showAllOnline() {
        final Collection<? extends Player> online = Bukkit.getOnlinePlayers();
        for (final Player player : online) {
            show(player);
        }
        refreshAll(online);
    }

    /** Called after authentication succeeded, so the sidebar and tablist entry appear then. */
    public void showPlayer(final Player player) {
        if (!player.isOnline()) {
            return;
        }
        show(player);
        if (displays.containsKey(player.getUniqueId())) {
            final Rank rank = ranks.rankOf(player.getUniqueId());
            final Scoreboard mainBoard = Bukkit.getScoreboardManager().getMainScoreboard();
            final Team team = mainBoard.getTeam("ranks" + rank.key());
            if (team != null) {
                team.addEntry(player.getName());
            }
            refreshAll();
        }
    }

    /** Called when a player logs out or is unregistered; removes their own display. */
    public void hidePlayer(final Player player) {
        final PlayerDisplay display = displays.remove(player.getUniqueId());
        if (display != null) {
            display.clear(player);
        }
        for (final PlayerDisplay other : displays.values()) {
            other.removeEntry(player.getName());
        }
    }

    private void show(final Player player) {
        if (!visible.test(player.getUniqueId())) {
            return;
        }
        if (!settings.scoreboardEnabled() && !settings.tablistEnabled()) {
            return;
        }
        displays.computeIfAbsent(
                player.getUniqueId(),
                id -> new PlayerDisplay(player, settings, stats, ranks, nicks, perks));
    }

    private void refreshAll() {
        refreshAll(Bukkit.getOnlinePlayers());
    }

    private void refreshAll(final Collection<? extends Player> online) {
        for (final Player player : online) {
            final PlayerDisplay display = displays.get(player.getUniqueId());
            if (display != null) {
                display.update(player, visibleOnline(player, online), online);
            }
        }
    }

    /** The online count as this viewer may see it; vanished players stay out of ordinary views. */
    private static int visibleOnline(
            final Player viewer, final Collection<? extends Player> online) {
        int count = 0;
        for (final Player other : online) {
            if (viewer.canSee(other)) {
                count++;
            }
        }
        return count;
    }

    private void startRefreshTask() {
        stopRefreshTask();
        if (!settings.scoreboardEnabled() && !settings.tablistEnabled()) {
            return;
        }
        refreshTask = Bukkit.getScheduler().runTaskTimer(
                plugin, () -> refreshAll(), REFRESH_TICKS, REFRESH_TICKS);
    }

    private void stopRefreshTask() {
        if (refreshTask != null) {
            refreshTask.cancel();
            refreshTask = null;
        }
    }
}