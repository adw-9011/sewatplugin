package io.github.near.sweats.display;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import io.github.near.sweats.rank.Rank;
import io.github.near.sweats.stats.PlayerProfile;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.junit.jupiter.api.Test;

class DisplaySnapshotTest {

    private static final long MINUTE = 20L * 60L;
    private static final Rank ADMIN = new Rank("Admin", Component.text("Admin", NamedTextColor.RED), 40, true);
    private static final Rank GRINDER = new Rank("Grinder", Component.text("Grinder", NamedTextColor.GREEN), 10, true);

    @Test
    void staysEqualWhileOnlySubMinutePlaytimeChanges() {
        final DisplaySnapshot first =
                DisplaySnapshot.of(new PlayerProfile(MINUTE, 100, 32), "Alex", ADMIN, "None", 24);
        final DisplaySnapshot second = DisplaySnapshot.of(
                new PlayerProfile(MINUTE + 59L * 20L, 100, 32), "Alex", ADMIN, "None", 24);

        assertEquals(first, second);
    }

    @Test
    void changesWhenAnyDisplayedValueChanges() {
        final DisplaySnapshot base =
                DisplaySnapshot.of(new PlayerProfile(MINUTE, 100, 32), "Alex", ADMIN, "None", 24);

        assertNotEquals(
                base,
                DisplaySnapshot.of(new PlayerProfile(MINUTE * 2L, 100, 32), "Alex", ADMIN, "None", 24));
        assertNotEquals(
                base,
                DisplaySnapshot.of(new PlayerProfile(MINUTE, 101, 32), "Alex", ADMIN, "None", 24));
        assertNotEquals(
                base,
                DisplaySnapshot.of(new PlayerProfile(MINUTE, 100, 33), "Alex", ADMIN, "None", 24));
        assertNotEquals(
                base,
                DisplaySnapshot.of(new PlayerProfile(MINUTE, 100, 32), "Steve", ADMIN, "None", 24));
        assertNotEquals(
                base,
                DisplaySnapshot.of(new PlayerProfile(MINUTE, 100, 32), "Alex", GRINDER, "None", 24));
        assertNotEquals(
                base,
                DisplaySnapshot.of(new PlayerProfile(MINUTE, 100, 32), "Alex", ADMIN, "Red", 24));
        assertNotEquals(
                base,
                DisplaySnapshot.of(new PlayerProfile(MINUTE, 100, 32), "Alex", ADMIN, "None", 25));
    }

    @Test
    void plusColourIsPartOfTheSnapshot() {
        final DisplaySnapshot plain = DisplaySnapshot.of(
                new PlayerProfile(MINUTE, 100, 32), "Alex", ADMIN, "None", 24, null);
        final DisplaySnapshot coloured = DisplaySnapshot.of(
                new PlayerProfile(MINUTE, 100, 32), "Alex", ADMIN, "None", 24, NamedTextColor.AQUA);
        final DisplaySnapshot same = DisplaySnapshot.of(
                new PlayerProfile(MINUTE, 100, 32), "Alex", ADMIN, "None", 24, NamedTextColor.AQUA);

        assertNotEquals(plain, coloured);
        assertEquals(coloured, same);
    }

    @Test
    void exposesTheFormattedValuesUsedByTheSidebar() {
        final DisplaySnapshot snapshot =
                DisplaySnapshot.of(new PlayerProfile(3_938_400L, 100, 32), "Alex", ADMIN, "None", 24);

        assertEquals("Alex", snapshot.playerName());
        assertEquals(ADMIN, snapshot.rank());
        assertEquals("None", snapshot.team());
        assertEquals("100", snapshot.kills());
        assertEquals("32", snapshot.deaths());
        assertEquals("2d 6h 42m", snapshot.playtime());
        assertEquals(24, snapshot.online());
    }
}