package io.github.near.sweats.display;

import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

final class DisplayLayout {

    static final int SIDEBAR_LINES = 15;

    private static final Component SEPARATOR =
            Component.text("--------------", NamedTextColor.DARK_GRAY, TextDecoration.STRIKETHROUGH);
    private static final Component BLANK = Component.text(" ", NamedTextColor.GRAY);

    private DisplayLayout() {}

    static Component sidebarTitle() {
        return Component.text("SWEATS", NamedTextColor.AQUA, TextDecoration.BOLD)
                .append(Component.text(" SMP", NamedTextColor.RED, TextDecoration.BOLD));
    }

    static List<Component> sidebar(final DisplaySnapshot snapshot, final DisplaySettings settings) {
        return List.of(
                SEPARATOR,
                Component.text("SWEATS", NamedTextColor.AQUA, TextDecoration.BOLD)
                        .append(Component.text(" SURVIVAL", NamedTextColor.RED, TextDecoration.BOLD)),
                SEPARATOR,
                BLANK,
                Component.text("Username: ", NamedTextColor.WHITE, TextDecoration.BOLD)
                        .append(Component.text(snapshot.playerName(), NamedTextColor.YELLOW)),
                Component.text("Team: ", NamedTextColor.WHITE, TextDecoration.BOLD)
                        .append(Component.text(snapshot.team(), NamedTextColor.RED)),
                Component.text("Rank: ", NamedTextColor.WHITE, TextDecoration.BOLD)
                        .append(snapshot.rank().isDefault()
                                ? Component.text("Default", NamedTextColor.GRAY)
                                : snapshot.rank().label(snapshot.plusColor())),
                Component.text("⚔ ", NamedTextColor.WHITE, TextDecoration.BOLD)
                        .append(Component.text("Kills: ", NamedTextColor.GRAY))
                        .append(Component.text(snapshot.kills(), NamedTextColor.RED)),
                Component.text("☠ ", NamedTextColor.WHITE, TextDecoration.BOLD)
                        .append(Component.text("Deaths: ", NamedTextColor.GRAY))
                        .append(Component.text(snapshot.deaths(), NamedTextColor.RED)),
                Component.text("◷ ", NamedTextColor.WHITE, TextDecoration.BOLD)
                        .append(Component.text("Playtime: ", NamedTextColor.GRAY))
                        .append(Component.text(snapshot.playtime(), NamedTextColor.RED)),
                Component.text("● ", NamedTextColor.GREEN, TextDecoration.BOLD)
                        .append(Component.text("Online: ", NamedTextColor.GRAY))
                        .append(Component.text(snapshot.online(), NamedTextColor.GREEN)),
                BLANK,
                SEPARATOR,
                Component.text(settings.serverAddress(), NamedTextColor.AQUA, TextDecoration.BOLD),
                SEPARATOR);
    }

    static Component tabListHeader(final DisplaySettings settings) {
        return Component.text("✦ S W E A T S ✦", DisplayTheme.PURPLE, TextDecoration.BOLD)
                .append(Component.newline())
                .append(Component.text(settings.serverName(), DisplayTheme.SECONDARY))
                .append(Component.newline())
                .append(Component.newline())
                .append(Component.text("Welcome to Sweats!", DisplayTheme.TEXT));
    }

    static Component tabListFooter(final int online, final int ping, final DisplaySettings settings) {
        return Component.text("ONLINE PLAYERS: ", DisplayTheme.SECONDARY)
                .append(Component.text(online, DisplayTheme.ONLINE))
                .append(Component.newline())
                .append(Component.text("YOUR PING: ", DisplayTheme.SECONDARY))
                .append(Component.text(ping + " ms", DisplayTheme.BLUE))
                .append(Component.newline())
                .append(Component.newline())
                .append(Component.text(settings.serverAddress(), DisplayTheme.BLUE));
    }
}
