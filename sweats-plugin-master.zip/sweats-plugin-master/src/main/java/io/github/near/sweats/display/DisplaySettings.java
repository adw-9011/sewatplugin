package io.github.near.sweats.display;

import org.bukkit.configuration.file.FileConfiguration;

public record DisplaySettings(
        boolean scoreboardEnabled,
        boolean tablistEnabled,
        String serverName,
        String serverAddress) {

    public static final String DEFAULT_SERVER_NAME = "SURVIVAL MULTIPLAYER";
    public static final String DEFAULT_SERVER_ADDRESS = "sweat.playsmp.xyz";

    public static DisplaySettings from(final FileConfiguration config) {
        return new DisplaySettings(
                config.getBoolean("scoreboard.enabled", true),
                config.getBoolean("tablist.enabled", true),
                text(config, "server.name", DEFAULT_SERVER_NAME),
                text(config, "server.address", DEFAULT_SERVER_ADDRESS));
    }

    private static String text(final FileConfiguration config, final String path, final String fallback) {
        final String value = config.getString(path);
        if (value == null || value.isBlank()) {
            return fallback;
        }
        return value;
    }
}
