package io.github.near.sweats.display;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

class DisplaySettingsTest {

    @Test
    void usesDocumentedDefaultsWhenNothingIsConfigured() {
        assertEquals(
                new DisplaySettings(
                        true,
                        true,
                        DisplaySettings.DEFAULT_SERVER_NAME,
                        DisplaySettings.DEFAULT_SERVER_ADDRESS),
                DisplaySettings.from(new YamlConfiguration()));
    }

    @Test
    void readsTheConfiguredSwitchesAndServerIdentity() {
        final YamlConfiguration config = new YamlConfiguration();
        config.set("scoreboard.enabled", false);
        config.set("tablist.enabled", false);
        config.set("server.name", "CREATIVE");
        config.set("server.address", "PLAY.EXAMPLE.NET");

        assertEquals(
                new DisplaySettings(false, false, "CREATIVE", "PLAY.EXAMPLE.NET"),
                DisplaySettings.from(config));
    }

    @Test
    void blankServerValuesFallBackToTheDefaults() {
        final YamlConfiguration config = new YamlConfiguration();
        config.set("server.name", "   ");
        config.set("server.address", "");

        final DisplaySettings settings = DisplaySettings.from(config);

        assertEquals(DisplaySettings.DEFAULT_SERVER_NAME, settings.serverName());
        assertEquals(DisplaySettings.DEFAULT_SERVER_ADDRESS, settings.serverAddress());
    }
}
