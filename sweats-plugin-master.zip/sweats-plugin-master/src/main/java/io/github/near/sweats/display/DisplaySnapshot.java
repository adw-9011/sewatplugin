package io.github.near.sweats.display;

import io.github.near.sweats.rank.Rank;
import io.github.near.sweats.stats.PlayerProfile;
import io.github.near.sweats.stats.StatsFormat;
import net.kyori.adventure.text.format.TextColor;

record DisplaySnapshot(
        String playerName,
        Rank rank,
        String team,
        String kills,
        String deaths,
        String playtime,
        int online,
        TextColor plusColor) {

    static DisplaySnapshot of(
            final PlayerProfile profile,
            final String playerName,
            final Rank rank,
            final String team,
            final int online) {
        return of(profile, playerName, rank, team, online, null);
    }

    static DisplaySnapshot of(
            final PlayerProfile profile,
            final String playerName,
            final Rank rank,
            final String team,
            final int online,
            final TextColor plusColor) {
        return new DisplaySnapshot(
                playerName,
                rank,
                team,
                StatsFormat.count(profile.kills()),
                StatsFormat.count(profile.deaths()),
                StatsFormat.playtime(profile.playtimeTicks()),
                online,
                plusColor);
    }
}
