package io.github.near.sweats.display;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.github.near.sweats.TestCommandSenders;
import io.github.near.sweats.rank.Rank;
import io.github.near.sweats.stats.PlayerProfile;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.junit.jupiter.api.Test;

class DisplayLayoutTest {

    private static final DisplaySettings SETTINGS = new DisplaySettings(
            true, true, "SURVIVAL MULTIPLAYER", "Sweats.net");
    private static final PlayerProfile PROFILE = new PlayerProfile(3_938_400L, 100, 32);
    private static final Rank ADMIN = new Rank("Admin", Component.text("Admin", NamedTextColor.RED), 40, true);
    private static final Rank DEFAULT = new Rank("Default", Component.text("Default", NamedTextColor.GRAY), 0, true);

    @Test
    void sidebarMatchesTheRequestedFifteenLineLayout() {
        final List<Component> lines = DisplayLayout.sidebar(snapshot(), SETTINGS);

        assertEquals(15, DisplayLayout.SIDEBAR_LINES);
        assertEquals(15, lines.size());
        assertEquals("--------------", plain(lines, 0));
        assertEquals("SWEATS SURVIVAL", plain(lines, 1));
        assertEquals("--------------", plain(lines, 2));
        assertEquals(" ", plain(lines, 3));
        assertEquals("Username: Alex", plain(lines, 4));
        assertEquals("Team: None", plain(lines, 5));
        assertEquals("Rank: [Admin]", plain(lines, 6));
        assertEquals("⚔ Kills: 100", plain(lines, 7));
        assertEquals("☠ Deaths: 32", plain(lines, 8));
        assertEquals("◷ Playtime: 2d 6h 42m", plain(lines, 9));
        assertEquals("● Online: 24", plain(lines, 10));
        assertEquals(" ", plain(lines, 11));
        assertEquals("--------------", plain(lines, 12));
        assertEquals("Sweats.net", plain(lines, 13));
        assertEquals("--------------", plain(lines, 14));
    }

    @Test
    void sidebarUsesTheRequestedColorCodes() {
        final List<Component> lines = DisplayLayout.sidebar(snapshot(), SETTINGS);

        assertEquals(TextDecoration.State.TRUE, lines.get(0).decoration(TextDecoration.STRIKETHROUGH));
        assertEquals(NamedTextColor.DARK_GRAY, lines.get(0).color());
        assertEquals(NamedTextColor.AQUA, lines.get(1).color());
        assertEquals(NamedTextColor.RED, colorOf(lines.get(1), " SURVIVAL"));
        assertEquals(NamedTextColor.WHITE, lines.get(4).color());
        assertEquals(NamedTextColor.YELLOW, colorOf(lines.get(4), "Alex"));
        assertEquals(NamedTextColor.RED, colorOf(lines.get(5), "None"));
        assertEquals(NamedTextColor.WHITE, lines.get(6).color());
        assertEquals(NamedTextColor.RED, colorOf(lines.get(6), "Admin"));
        assertEquals(NamedTextColor.WHITE, lines.get(7).color());
        assertEquals(NamedTextColor.GRAY, colorOf(lines.get(7), "Kills: "));
        assertEquals(NamedTextColor.RED, colorOf(lines.get(7), "100"));
        assertEquals(NamedTextColor.RED, colorOf(lines.get(8), "32"));
        assertEquals(NamedTextColor.RED, colorOf(lines.get(9), "2d 6h 42m"));
        assertEquals(NamedTextColor.GREEN, lines.get(10).color());
        assertEquals(NamedTextColor.GRAY, colorOf(lines.get(10), "Online: "));
        assertEquals(NamedTextColor.GREEN, colorOf(lines.get(10), "24"));
        assertEquals(NamedTextColor.AQUA, lines.get(13).color());
    }

    @Test
    void sidebarShowsDefaultForPlayersWithoutARankTag() {
        final List<Component> lines = DisplayLayout.sidebar(
                DisplaySnapshot.of(PROFILE, "Alex", DEFAULT, "None", 24), SETTINGS);

        assertEquals("Rank: Default", plain(lines, 6));
        assertEquals(NamedTextColor.GRAY, colorOf(lines.get(6), "Default"));
    }

    @Test
    void sidebarShowsZeroAndLargeValues() {
        final List<Component> zero = DisplayLayout.sidebar(
                DisplaySnapshot.of(new PlayerProfile(0L, 0, 0), "Alex", ADMIN, "None", 0), SETTINGS);
        assertEquals("Username: Alex", plain(zero, 4));
        assertEquals("Team: None", plain(zero, 5));
        assertEquals("Rank: [Admin]", plain(zero, 6));
        assertEquals("⚔ Kills: 0", plain(zero, 7));
        assertEquals("☠ Deaths: 0", plain(zero, 8));
        assertEquals("◷ Playtime: 0m", plain(zero, 9));
        assertEquals("● Online: 0", plain(zero, 10));

        final PlayerProfile large =
                new PlayerProfile(Long.MAX_VALUE / 4L, Integer.MAX_VALUE, Integer.MAX_VALUE);
        final List<Component> lines = DisplayLayout.sidebar(
                DisplaySnapshot.of(large, "AReallyLongUsername", ADMIN, "Red", 1000), SETTINGS);

        assertEquals("Username: AReallyLongUsername", plain(lines, 4));
        assertEquals("Team: Red", plain(lines, 5));
        assertEquals("Rank: [Admin]", plain(lines, 6));
        assertEquals("⚔ Kills: 2,147,483,647", plain(lines, 7));
        assertEquals("☠ Deaths: 2,147,483,647", plain(lines, 8));
        assertTrue(plain(lines, 9).startsWith("◷ Playtime: "));
        assertEquals("● Online: 1000", plain(lines, 10));
    }

    @Test
    void sidebarShowsShortAndLongPlaytimes() {
        final long halfHour = 20L * (31L * 60L);
        final List<Component> shortPlaytime = DisplayLayout.sidebar(
                DisplaySnapshot.of(new PlayerProfile(halfHour, 0, 0), "Alex", ADMIN, "None", 1), SETTINGS);
        assertEquals("◷ Playtime: 31m", plain(shortPlaytime, 9));

        final long thousandDays = 20L * (1_000L * 86_400L);
        final List<Component> longPlaytime = DisplayLayout.sidebar(
                DisplaySnapshot.of(new PlayerProfile(thousandDays, 0, 0), "Alex", ADMIN, "None", 1), SETTINGS);
        assertEquals("◷ Playtime: 1000d 0h 0m", plain(longPlaytime, 9));
    }

    @Test
    void titleIsSweatsSmp() {
        assertEquals("SWEATS SMP", TestCommandSenders.plain(DisplayLayout.sidebarTitle()));
        assertEquals(NamedTextColor.AQUA, DisplayLayout.sidebarTitle().color());
        assertEquals(NamedTextColor.RED, colorOf(DisplayLayout.sidebarTitle(), " SMP"));
    }

    @Test
    void tabListHeaderShowsTheServerAndWelcome() {
        assertEquals(
                "✦ S W E A T S ✦\nSURVIVAL MULTIPLAYER\n\nWelcome to Sweats!",
                TestCommandSenders.plain(DisplayLayout.tabListHeader(SETTINGS)));
    }

    @Test
    void tabListFooterShowsOnlineCountPingAndAddress() {
        assertEquals(
                "ONLINE PLAYERS: 24\nYOUR PING: 42 ms\n\nSweats.net",
                TestCommandSenders.plain(DisplayLayout.tabListFooter(24, 42, SETTINGS)));
    }

    private static DisplaySnapshot snapshot() {
        return DisplaySnapshot.of(PROFILE, "Alex", ADMIN, "None", 24);
    }

    private static String plain(final List<Component> lines, final int index) {
        return TestCommandSenders.plain(lines.get(index));
    }

    private static TextColor colorOf(final Component component, final String content) {
        if (component instanceof final TextComponent text && text.content().equals(content)) {
            return text.color();
        }
        for (final Component child : component.children()) {
            final TextColor color = colorOf(child, content);
            if (color != null) {
                return color;
            }
        }
        return null;
    }
}